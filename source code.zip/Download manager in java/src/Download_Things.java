import java.io.*;
import java.net.*;

public class Download_Things implements Runnable{
	
    String link;
    public File out;
    BufferedOutputStream bout;
    String downloadPath = "C:\\Users\\chetan\\Downloads\\";
    Download_Things(String link) {
		this.link = link;
    }
    
    private void getFileName(URL url){
            String fileName = url.getFile();
            File out1;
            out1 = new File(downloadPath+fileName.substring(fileName.lastIndexOf("/")+1));
            if(out1.exists()){
                for(int i=1;true;i++){
                    out1 = new File(downloadPath+"("+i+")"+fileName.substring(fileName.lastIndexOf("/")+1));
                    if (!out1.exists())
                        break;
                }
            }
            this.out=out1;
    }
    
    @Override
    public void run(){
        try{
            URL url = new URL(link);      
            HttpURLConnection http = (HttpURLConnection)url.openConnection();
            double filesize = (double)http.getContentLengthLong();
            BufferedInputStream in = new BufferedInputStream(http.getInputStream());
            getFileName(url);
            FileOutputStream fos = new FileOutputStream(this.out);
            bout = new BufferedOutputStream(fos,1024);
            byte[] buffer = new byte[1024];
            double download = 0.00;
            int read = 0;
            double percentageDownload = 0.00;
            int srNo = MainFrame.jTable1.getRowCount();
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) MainFrame.jTable1.getModel();
            model.addRow(new String[] {String.valueOf(srNo+1),String.valueOf(link),String.format("%.2f",(double)http.getContentLength()/1000000)+"MB",String.valueOf(percentageDownload),"Downloading..."});
            while((read = in.read(buffer,0,1024))>=0){
                bout.write(buffer,0,read);
                download+=read;
                percentageDownload = (download*100)/filesize;
                String percent = String.format("%.2f",percentageDownload);
                model.setValueAt(percent+"%", srNo, 3);
            }
            bout.close();
            in.close();			
            model.setValueAt("Completed", srNo, 4);
        }
        catch(IOException ex) {
            javax.swing.JOptionPane.showMessageDialog(null, "Please enter valid url\nOr check your internet connection");
        }
    }
}